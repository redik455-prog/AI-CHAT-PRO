plugins { id("com.android.application") }

android {
    namespace = "com.cryptopredictor.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.cryptopredictor.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 2
        versionName = "2.0"
    }
}

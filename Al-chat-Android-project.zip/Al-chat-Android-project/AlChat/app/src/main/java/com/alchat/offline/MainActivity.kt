package com.alchat.offline

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private val Bg = Color(0xFF080B16)
private val Panel = Color(0x22FFFFFF)
private val Violet = Color(0xFF9B7BFF)
private val Cyan = Color(0xFF62DDF3)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AlChatScreen() }
    }
}

data class ChatMessage(val text: String, val fromUser: Boolean)

@Composable
fun AlChatScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val messages = remember { mutableStateListOf(
        ChatMessage("Привет! Я Al chat — локальный ИИ-помощник. Подключи языковую модель, и мы сможем общаться без интернета.", false)
    ) }
    var input by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Модель не установлена") }
    var busy by remember { mutableStateOf(false) }
    var engine by remember { mutableStateOf<LlmInference?>(null) }
    var modelPath by remember { mutableStateOf<String?>(null) }

    fun installModel(uri: Uri) {
        scope.launch {
            busy = true
            status = "Импорт модели…"
            try {
                val destination = File(context.filesDir, "model.task")
                withContext(Dispatchers.IO) {
                    context.contentResolver.openInputStream(uri).use { stream ->
                        requireNotNull(stream) { "Не удалось открыть файл" }.use { input ->
                            destination.outputStream().use { output -> input.copyTo(output) }
                        }
                    }
                }
                status = "Загрузка движка…"
                val newEngine = withContext(Dispatchers.Default) {
                    val options = LlmInference.LlmInferenceOptions.builder()
                        .setModelPath(destination.absolutePath)
                        .setMaxTokens(512)
                        .build()
                    LlmInference.createFromOptions(context, options)
                }
                engine?.close()
                engine = newEngine
                modelPath = destination.absolutePath
                status = "Модель готова · Offline"
                messages.add(ChatMessage("Модель подключена. Теперь ответы генерируются на устройстве.", false))
            } catch (e: Exception) {
                status = "Ошибка модели"
                messages.add(ChatMessage("Не удалось загрузить модель: ${e.localizedMessage ?: "неизвестная ошибка"}. Проверь, что это совместимая модель MediaPipe GenAI формата .task.", false))
            } finally { busy = false }
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) installModel(uri)
    }

    fun send() {
        val prompt = input.trim()
        if (prompt.isEmpty() || busy) return
        messages.add(ChatMessage(prompt, true))
        input = ""
        val active = engine
        if (active == null) {
            messages.add(ChatMessage("Сначала установи совместимую локальную модель через кнопку скрепки. Без файла модели я не могу генерировать ответы.", false))
            return
        }
        busy = true
        scope.launch {
            try {
                val answer = withContext(Dispatchers.Default) {
                    active.generateResponse(prompt)
                }
                messages.add(ChatMessage(answer, false))
            } catch (e: Exception) {
                messages.add(ChatMessage("Ошибка генерации: ${e.localizedMessage ?: "попробуй ещё раз"}", false))
            } finally { busy = false }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Color(0xFF11172A), primary = Violet,
        secondary = Cyan, onBackground = Color.White, onSurface = Color.White
    )) {
        Box(Modifier.fillMaxSize().background(
            Brush.linearGradient(listOf(Color(0xFF11142B), Bg, Color(0xFF101D2C)))
        )) {
            Box(Modifier.align(Alignment.TopEnd).padding(top = 35.dp, end = 10.dp)
                .size(180.dp).blur(65.dp).background(Violet.copy(alpha = .25f), CircleShape))
            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Box(Modifier.size(46.dp).clip(RoundedCornerShape(15.dp))
                        .background(Brush.linearGradient(listOf(Violet, Cyan))),
                        contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Memory, null, tint = Color.White, modifier = Modifier.size(27.dp))
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Al chat", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("Локальный искусственный интеллект", fontSize = 11.sp, color = Color.LightGray)
                    }
                    IconButton(onClick = { picker.launch(arrayOf("*/*")) }) {
                        Icon(Icons.Default.Settings, "Установить модель", tint = Color.White)
                    }
                }
                Spacer(Modifier.height(14.dp))
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                        .background(Panel).padding(horizontal = 13.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(8.dp).clip(CircleShape)
                        .background(if (engine != null) Color(0xFF59E6A5) else Color(0xFFFFC36B)))
                    Spacer(Modifier.width(9.dp))
                    Text(status, color = Color.White.copy(alpha = .85f), fontSize = 12.sp)
                    Spacer(Modifier.weight(1f))
                    Text("OFFLINE", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(14.dp))
                LazyColumn(
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(vertical = 8.dp)
                ) {
                    items(messages) { msg ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement =
                            if (msg.fromUser) Arrangement.End else Arrangement.Start) {
                            Column(
                                Modifier.widthIn(max = 310.dp)
                                    .clip(RoundedCornerShape(
                                        topStart = 18.dp, topEnd = 18.dp,
                                        bottomStart = if (msg.fromUser) 18.dp else 5.dp,
                                        bottomEnd = if (msg.fromUser) 5.dp else 18.dp
                                    ))
                                    .background(if (msg.fromUser)
                                        Brush.linearGradient(listOf(Color(0xFF6954B8), Color(0xFF3E78A0)))
                                    else Brush.linearGradient(listOf(Color(0x33FFFFFF), Color(0x1AFFFFFF)))
                                    )
                                    .padding(14.dp)
                            ) {
                                if (!msg.fromUser) Text("AL CHAT", color = Cyan, fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold)
                                Text(msg.text, color = Color.White, fontSize = 14.sp, lineHeight = 20.sp)
                            }
                        }
                    }
                    if (busy) item {
                        Text("Al chat думает…", color = Cyan, fontSize = 12.sp)
                    }
                }
                AnimatedVisibility(visible = engine == null) {
                    Text("Для работы нужен совместимый файл модели .task. Нажми скрепку, чтобы импортировать его.",
                        color = Color(0xFFFFD28B), fontSize = 11.sp,
                        modifier = Modifier.padding(bottom = 9.dp))
                }
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp))
                        .background(Color(0x33FFFFFF)).padding(horizontal = 8.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { picker.launch(arrayOf("*/*")) }, enabled = !busy) {
                        Icon(Icons.Default.AttachFile, "Выбрать модель", tint = Cyan)
                    }
                    BasicTextField(
                        value = input, onValueChange = { input = it },
                        modifier = Modifier.weight(1f).padding(horizontal = 7.dp),
                        enabled = !busy,
                        textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 14.sp),
                        cursorBrush = androidx.compose.ui.graphics.SolidColor(Cyan),
                        decorationBox = { inner ->
                            Box {
                                if (input.isEmpty()) Text("Напиши сообщение…", color = Color.Gray, fontSize = 14.sp)
                                inner()
                            }
                        }
                    )
                    IconButton(onClick = { send() }, enabled = !busy && input.isNotBlank()) {
                        Icon(Icons.Default.Send, "Отправить", tint = Cyan)
                    }
                }
                Spacer(Modifier.height(7.dp))
                Text("Ответы создаются на устройстве после установки модели",
                    color = Color.Gray, fontSize = 10.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
            }
        }
    }
}

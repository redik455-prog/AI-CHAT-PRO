package com.alchat.trader

import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceError
import android.webkit.WebSettings
import android.util.Log
import android.graphics.Color
import android.webkit.CookieManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.abs

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            MaterialTheme {
                TraderScreen()
            }
        }
    }
}

data class Candle(
    val openTime: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double
)

data class Analysis(
    val symbol: String,
    val price: Double,
    val trend: String,
    val rsi: Double,
    val ema9: Double,
    val ema21: Double,
    val macd: Double,
    val atr: Double,
    val volumeRatio: Double,
    val score: Int,
    val signal: String,
    val details: List<String>
)

@Composable
fun TraderScreen() {
    var symbol by remember { mutableStateOf("BTCUSDT") }
    var selectedTab by remember { mutableIntStateOf(0) }
    var analysis by remember { mutableStateOf<Analysis?>(null) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var refresh by remember { mutableIntStateOf(0) }

    LaunchedEffect(symbol, refresh) {
        loading = true
        error = null

        try {
            analysis = MarketAnalyzer.load(symbol)
        } catch (e: Exception) {
            error = e.message ?: "Не удалось получить рыночные данные"
        } finally {
            loading = false
        }
    }

    Scaffold(
        topBar = {
            TopAppBarCompat(
                title = "Al chat · Технический анализ",
                subtitle = "Без ИИ · Binance market data"
            )
        }
    ) { padding ->
        Column(
            Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = symbol == "BTCUSDT",
                    onClick = { symbol = "BTCUSDT" },
                    label = { Text("BTC/USDT") }
                )

                FilterChip(
                    selected = symbol == "ETHUSDT",
                    onClick = { symbol = "ETHUSDT" },
                    label = { Text("ETH/USDT") }
                )

                Spacer(Modifier.weight(1f))

                Button(
                    onClick = { refresh++ },
                    enabled = !loading
                ) {
                    Text("Обновить")
                }
            }

            TabRow(selectedTabIndex = selectedTab) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Анализ") }
                )

                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("TradingView") }
                )
            }

            if (selectedTab == 1) {
                TradingViewPanel(symbol)
            } else {
                Text("Таймфрейм сигнала: 5 минут · Контекст: 15 минут и 1 час")

                if (loading) {
                    LinearProgressIndicator(Modifier.fillMaxWidth())
                }

                error?.let {
                    Text(
                        "Ошибка: $it",
                        color = MaterialTheme.colorScheme.error
                    )
                }

                analysis?.let {
                    AnalysisCard(it)
                }

                Text(
                    "Это аналитический инструмент, а не гарантия прибыли. " +
                    "Сначала проверяйте сигналы на демо-счёте. " +
                    "Показатель score — оценка совпадения правил, а не вероятность выигрыша.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

@Composable
fun TopAppBarCompat(title: String, subtitle: String) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        Text(title, style = MaterialTheme.typography.titleLarge)

        Text(
            subtitle,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.secondary
        )
    }
}

@Composable
fun AnalysisCard(a: Analysis) {
    Card(Modifier.fillMaxWidth()) {
        Column(
            Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(a.symbol, style = MaterialTheme.typography.titleLarge)

            Text(
                String.format("Цена: %.4f", a.price),
                style = MaterialTheme.typography.headlineSmall
            )

            Text(
                a.signal,
                style = MaterialTheme.typography.headlineMedium,
                color = when (a.signal) {
                    "ВВЕРХ" -> MaterialTheme.colorScheme.primary
                    "ВНИЗ" -> MaterialTheme.colorScheme.error
                    else -> MaterialTheme.colorScheme.secondary
                }
            )

            Text("Оценка условий: ${a.score}/100")

            HorizontalDivider()

            Metric("Тренд 1H", a.trend)
            Metric("RSI (5M)", "%.1f".format(a.rsi))
            Metric("EMA 9 / 21", "%.4f / %.4f".format(a.ema9, a.ema21))
            Metric("MACD", "%.5f".format(a.macd))
            Metric("ATR (5M)", "%.5f".format(a.atr))
            Metric("Объём / средний", "%.2fx".format(a.volumeRatio))

            HorizontalDivider()

            Text("Проверки", style = MaterialTheme.typography.titleMedium)

            a.details.forEach {
                Text("• $it", style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
fun Metric(name: String, value: String) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(name)
        Text(value, style = MaterialTheme.typography.labelLarge)
    }
}

@Composable
fun TradingViewPanel(symbol: String) {
    val tvSymbol = if (symbol == "BTCUSDT") {
        "BINANCE:BTCUSDT"
    } else {
        "BINANCE:ETHUSDT"
    }

    key(tvSymbol) {
        AndroidView(
            modifier = Modifier
                .fillMaxWidth()
                .height(520.dp),

            factory = { context ->
                WebView(context).apply {
                    setBackgroundColor(Color.rgb(19, 23, 34))

                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.loadsImagesAutomatically = true
                    settings.mixedContentMode =
                        WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                    settings.useWideViewPort = true
                    settings.loadWithOverviewMode = true

                    CookieManager
                        .getInstance()
                        .setAcceptThirdPartyCookies(this, true)

                    webViewClient = object : WebViewClient() {
                        override fun onReceivedError(
                            view: WebView,
                            request: WebResourceRequest,
                            error: WebResourceError
                        ) {
                            if (request.isForMainFrame) {
                                Log.e(
                                    "TradingView",
                                    "Ошибка: ${error.description}"
                                )
                            }
                        }
                    }

                    loadUrl(
                        "https://www.tradingview.com/widgetembed/" +
                        "?symbol=$tvSymbol" +
                        "&interval=5" +
                        "&hidesidetoolbar=0" +
                        "&symboledit=1" +
                        "&saveimage=0" +
                        "&toolbarbg=131722" +
                        "&theme=dark" +
                        "&style=1" +
                        "&timezone=Etc%2FUTC" +
                        "&withdateranges=1" +
                        "&locale=ru"
                    )
                }
            }
        )
    }
}

object MarketAnalyzer {
    private const val BASE =
        "https://api.binance.com/api/v3/klines"

    suspend fun load(symbol: String): Analysis =
        withContext(Dispatchers.IO) {

            val five = fetch(symbol, "5m", 120)
            val hour = fetch(symbol, "1h", 80)

            require(five.size >= 30 && hour.size >= 30) {
                "Недостаточно свечей для расчёта"
            }

            val closes = five.map { it.close }
            val highs = five.map { it.high }
            val lows = five.map { it.low }
            val volumes = five.map { it.volume }

            val ema9 = ema(closes, 9)
            val ema21 = ema(closes, 21)
            val ema50Hour = ema(hour.map { it.close }, 50)
            val rsi = rsi(closes, 14)
            val macd = ema(closes, 12) - ema(closes, 26)
            val atr = atr(five, 14)

            val avgVol = volumes
                .takeLast(21)
                .dropLast(1)
                .average()
                .coerceAtLeast(0.0000001)

            val volRatio = volumes.last() / avgVol
            val hourClose = hour.last().close

            val trend = if (hourClose > ema50Hour) {
                "Восходящий"
            } else {
                "Нисходящий"
            }

            var up = 0
            var down = 0

            val checks = mutableListOf<String>()

            fun check(
                label: String,
                bullish: Boolean,
                bearish: Boolean
            ) {
                when {
                    bullish -> {
                        up++
                        checks += "$label: подтверждает рост"
                    }

                    bearish -> {
                        down++
                        checks += "$label: подтверждает падение"
                    }

                    else -> {
                        checks += "$label: нейтрально"
                    }
                }
            }

            check(
                "Тренд 1H",
                hourClose > ema50Hour,
                hourClose < ema50Hour
            )

            check("EMA 9/21", ema9 > ema21, ema9 < ema21)

            check(
                "RSI",
                rsi in 50.0..68.0,
                rsi in 32.0..50.0
            )

            check("MACD", macd > 0, macd < 0)

            check(
                "Объём",
                volRatio >= 1.2 &&
                    closes.last() > closes[closes.lastIndex - 1],
                volRatio >= 1.2 &&
                    closes.last() < closes[closes.lastIndex - 1]
            )

            val range =
                highs.takeLast(20).maxOrNull()!! -
                lows.takeLast(20).minOrNull()!!

            val enoughVolatility = atr > 0 && range > atr

            checks += if (enoughVolatility) {
                "Волатильность: движение есть"
            } else {
                "Волатильность: низкая"
            }

            val score = (maxOf(up, down) * 20).coerceIn(0, 100)

            val signal = when {
                up >= 5 && up > down &&
                    rsi < 68 && enoughVolatility -> "ВВЕРХ"

                down >= 5 && down > up &&
                    rsi > 32 && enoughVolatility -> "ВНИЗ"

                else -> "НЕТ СДЕЛКИ"
            }

            Analysis(
                symbol,
                closes.last(),
                trend,
                rsi,
                ema9,
                ema21,
                macd,
                atr,
                volRatio,
                score,
                signal,
                checks
            )
        }

    private fun fetch(
        symbol: String,
        interval: String,
        limit: Int
    ): List<Candle> {
        val url = URL(
            "$BASE?symbol=$symbol&interval=$interval&limit=$limit"
        )

        val connection =
            (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 12000
                readTimeout = 12000
                requestMethod = "GET"
            }

        try {
            val code = connection.responseCode

            val stream = if (code in 200..299) {
                connection.inputStream
            } else {
                connection.errorStream
            }

            val body = stream.bufferedReader().use {
                it.readText()
            }

            if (code !in 200..299) {
                error("Binance HTTP $code: $body")
            }

            val json = JSONArray(body)

            return (0 until json.length()).map { i ->
                val row = json.getJSONArray(i)

                Candle(
                    row.getLong(0),
                    row.getString(1).toDouble(),
                    row.getString(2).toDouble(),
                    row.getString(3).toDouble(),
                    row.getString(4).toDouble(),
                    row.getString(5).toDouble()
                )
            }
        } finally {
            connection.disconnect()
        }
    }

    private fun ema(
        values: List<Double>,
        period: Int
    ): Double {
        val k = 2.0 / (period + 1)

        return values.drop(1).fold(values.first()) { acc, v ->
            v * k + acc * (1 - k)
        }
    }

    private fun rsi(
        values: List<Double>,
        period: Int
    ): Double {
        val changes = values
            .zipWithNext { a, b -> b - a }
            .takeLast(period)

        val gain =
            changes.filter { it > 0 }.sum() / period

        val loss =
            -changes.filter { it < 0 }.sum() / period

        if (loss == 0.0) return 100.0

        return 100.0 - (100.0 / (1.0 + gain / loss))
    }

    private fun atr(
        candles: List<Candle>,
        period: Int
    ): Double {
        val tr = candles.zipWithNext { prev, cur ->
            maxOf(
                cur.high - cur.low,
                abs(cur.high - prev.close),
                abs(cur.low - prev.close)
            )
        }

        return tr.takeLast(period).average()
    }
}

package com.aichatpro.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import android.text.InputType

class MainActivity : Activity() {
    private lateinit var messages: LinearLayout
    private lateinit var input: EditText
    private lateinit var status: TextView

    private val bg = Color.rgb(10, 11, 24)
    private val panel = Color.rgb(24, 25, 48)
    private val accent = Color.rgb(143, 103, 255)
    private val white = Color.WHITE
    private var modelReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(18, 20, 18, 14)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(4, 8, 4, 18)
        }
        val title = TextView(this).apply {
            text = "AI CHAT PRO"
            textSize = 25f
            setTextColor(white)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }
        status = TextView(this).apply {
            text = "Локальный ИИ • модель ещё не подключена"
            textSize = 12f
            setTextColor(Color.rgb(176, 169, 214))
            setPadding(0, 6, 0, 0)
        }
        header.addView(title)
        header.addView(status)
        root.addView(header)

        val welcome = TextView(this).apply {
            text = "Привет! Я AI CHAT PRO.\n\nЭто стартовая версия приложения. Чтобы я действительно отвечал офлайн, нужно подключить локальный движок и файл языковой модели GGUF. Сейчас экран чата готов, но генерация ответов ещё не подключена."
            textSize = 16f
            setTextColor(white)
            setPadding(16, 18, 16, 18)
            setBackgroundColor(panel)
        }
        root.addView(welcome)

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            setPadding(0, 14, 0, 10)
        }
        messages = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(messages)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val modelButton = Button(this).apply {
            text = "ПОДКЛЮЧИТЬ ЛОКАЛЬНУЮ МОДЕЛЬ"
            setTextColor(white)
            setBackgroundColor(Color.rgb(65, 48, 130))
            setOnClickListener {
                Toast.makeText(this@MainActivity,
                    "В этой сборке движок GGUF ещё не встроен. Не выбирай случайные файлы модели.",
                    Toast.LENGTH_LONG).show()
            }
        }
        root.addView(modelButton)

        val composer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 10, 0, 0)
        }
        input = EditText(this).apply {
            hint = "Напиши сообщение…"
            setHintTextColor(Color.LTGRAY)
            setTextColor(white)
            textSize = 15f
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            setPadding(14, 10, 14, 10)
            setBackgroundColor(panel)
        }
        composer.addView(input, LinearLayout.LayoutParams(0, 54, 1f))
        val send = Button(this).apply {
            text = "➤"
            textSize = 20f
            setTextColor(white)
            setBackgroundColor(accent)
            setOnClickListener {
                val text = input.text.toString().trim()
                if (text.isNotEmpty()) {
                    addMessage("Вы", text, true)
                    addMessage("AI CHAT PRO", "Локальная модель пока не подключена. После интеграции GGUF-движка я смогу отвечать без интернета.", false)
                    input.text.clear()
                }
            }
        }
        composer.addView(send, LinearLayout.LayoutParams(58, 54))
        root.addView(composer)
        setContentView(root)
    }

    private fun addMessage(who: String, body: String, user: Boolean) {
        val card = TextView(this).apply {
            text = "$who\n$body"
            textSize = 15f
            setTextColor(white)
            setPadding(14, 12, 14, 12)
            setBackgroundColor(if (user) Color.rgb(58, 48, 104) else panel)
        }
        val params = LinearLayout.LayoutParams(
            if (user) (resources.displayMetrics.widthPixels * 0.82).toInt() else -1,
            -2
        )
        params.gravity = if (user) Gravity.END else Gravity.START
        params.setMargins(0, 5, 0, 5)
        messages.addView(card, params)
    }
}

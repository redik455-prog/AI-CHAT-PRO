package com.aichatpro.app

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.database.Cursor
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.animation.ObjectAnimator
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.provider.OpenableColumns
import android.widget.*
import android.text.InputType
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {

    private val prefs by lazy {
        getSharedPreferences("ai_chat_pro", MODE_PRIVATE)
    }

    private var screen = "home"
    private var neon = true
    private var modelName = "Модель не выбрана"
    private var modelUri: Uri? = null

    private data class Message(
        val author: String,
        val text: String,
        val user: Boolean
    )

    private val messages = mutableListOf<Message>()

    private val bg get() = Color.rgb(8, 9, 20)
    private val panel get() = Color.rgb(25, 26, 45)
    private val white get() = Color.WHITE
    private val muted get() = Color.rgb(165, 165, 190)

    private val cyan get() = if (neon) Color.rgb(55, 225, 255) else Color.rgb(150, 150, 175)
    private val purple get() = if (neon) Color.rgb(165, 90, 255) else Color.rgb(110, 110, 140)
    private val pink get() = if (neon) Color.rgb(255, 70, 190) else Color.rgb(130, 110, 135)
    private val green get() = if (neon) Color.rgb(55, 230, 170) else Color.rgb(110, 145, 130)

    private var glowAnimator: ObjectAnimator? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        neon = prefs.getBoolean("neon", true)
        modelName = prefs.getString("model_name", "Модель не выбрана")!!

        val savedUri = prefs.getString("model_uri", null)
        if (savedUri != null) {
            modelUri = Uri.parse(savedUri)
        }

        loadMessages()
        render()
    }

    private fun render() {
        glowAnimator?.cancel()

        window.statusBarColor = bg
        window.navigationBarColor = bg

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(16), dp(10), dp(16), dp(8))
        }

        // HEADER
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(5), 0, dp(12))
        }

        val logo = TextView(this).apply {
            text = "✦"
            textSize = 27f
            gravity = Gravity.CENTER
            setTextColor(cyan)
            background = rounded(
                intArrayOf(purple, Color.rgb(25, 35, 75)), 16
            )
        }

        header.addView(logo, LinearLayout.LayoutParams(dp(45), dp(45)))

        val heading = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), 0, 0, 0)
        }

        heading.addView(label("AI CHAT PRO", 19f, white, true))
        heading.addView(label("NEON FUTURE EDITION", 9f, cyan))

        header.addView(
            heading,
            LinearLayout.LayoutParams(0, -2, 1f)
        )

        val menu = TextView(this).apply {
            text = "✧"
            textSize = 25f
            gravity = Gravity.CENTER
            setTextColor(pink)
            setOnClickListener {
                screen = "settings"
                render()
            }
        }

        header.addView(menu, LinearLayout.LayoutParams(dp(40), dp(45)))
        root.addView(header)

        // CONTENT
        val content = FrameLayout(this)
        val page = when (screen) {
            "chat" -> chatPage()
            "models" -> modelsPage()
            "history" -> historyPage()
            "settings" -> settingsPage()
            else -> homePage()
        }

        content.addView(
            page,
            FrameLayout.LayoutParams(-1, -1)
        )

        root.addView(
            content,
            LinearLayout.LayoutParams(-1, 0, 1f)
        )

        // BOTTOM NAVIGATION
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = rounded(
                intArrayOf(
                    Color.rgb(23, 23, 43),
                    Color.rgb(17, 18, 33)
                ), 20
            )
            setPadding(0, dp(7), 0, dp(7))
        }

        addNav(nav, "⌂", "Главная", "home")
        addNav(nav, "✉", "Чат", "chat")
        addNav(nav, "◈", "Модели", "models")
        addNav(nav, "◷", "История", "history")
        addNav(nav, "⚙", "Настройки", "settings")

        root.addView(
            nav,
            LinearLayout.LayoutParams(-1, dp(65)).apply {
                topMargin = dp(9)
            }
        )

        setContentView(root)
    }

    private fun homePage(): View {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(5), 0, dp(15))
        }

        // HERO CARD
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(22))
            background = rounded(
                intArrayOf(
                    Color.rgb(52, 25, 91),
                    Color.rgb(23, 31, 77),
                    Color.rgb(12, 47, 65)
                ), 25
            )
        }

        val glow = label("✧  YOUR PERSONAL AI ASSISTANT", 10f, cyan, true)
        hero.addView(glow)

        glowAnimator = ObjectAnimator.ofFloat(
            glow, "alpha", 0.55f, 1f
        ).apply {
            duration = 1400
            repeatCount = ObjectAnimator.INFINITE
            repeatMode = ObjectAnimator.REVERSE
            start()
        }

        hero.addView(
            label("Привет! 👋", 29f, white, true).apply {
                setPadding(0, dp(14), 0, dp(5))
            }
        )

        hero.addView(
            label(
                "Добро пожаловать в AI CHAT PRO. Твой интеллектуальный помощник всегда рядом.",
                14f,
                Color.rgb(215, 215, 240)
            )
        )

        hero.addView(
            label(
                "●  $modelName",
                11f,
                if (modelUri != null) green else Color.rgb(255, 190, 110),
                true
            ).apply {
                setPadding(0, dp(17), 0, 0)
            }
        )

        content.addView(
            hero,
            LinearLayout.LayoutParams(-1, -2).apply {
                bottomMargin = dp(20)
            }
        )

        content.addView(
            label("БЫСТРЫЙ ДОСТУП", 12f, muted, true).apply {
                setPadding(dp(3), 0, 0, dp(10))
            }
        )

        addActionRow(
            content,
            arrayOf(
                Triple("✦", "Новый чат", cyan),
                Triple("◈", "Мои модели", purple)
            )
        )

        addActionRow(
            content,
            arrayOf(
                Triple("◷", "История", green),
                Triple("⚙", "Настройки", pink)
            )
        )

        val tip = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(15), dp(16), dp(15))
            background = rounded(intArrayOf(panel), 18)
        }

        tip.addView(label("ВАШ AI-ПОМOЩНИК", 11f, cyan, true))
        tip.addView(
            label(
                "Выбери модель GGUF в разделе «Модели», чтобы подготовить её к локальному запуску.",
                13f,
                white
            ).apply {
                setPadding(0, dp(8), 0, 0)
            }
        )

        content.addView(tip)

        scroll.addView(content)
        page.addView(scroll)

        return page
    }

    private fun addActionRow(
        parent: LinearLayout,
        items: Array<Triple<String, String, Int>>
    ) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }

        items.forEachIndexed { index, item ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                background = rounded(
                    intArrayOf(
                        Color.rgb(29, 30, 52),
                        Color.rgb(19, 21, 39)
                    ), 19
                )
                setOnClickListener {
                    when (item.second) {
                        "Новый чат" -> {
                            messages.clear()
                            saveMessages()
                            screen = "chat"
                        }
                        "Мои модели" -> screen = "models"
                        "История" -> screen = "history"
                        "Настройки" -> screen = "settings"
                    }
                    render()
                }
            }

            card.addView(
                label(item.first, 28f, item.third).apply {
                    gravity = Gravity.CENTER
                }
            )

            card.addView(
                label(item.second, 13f, white, true).apply {
                    gravity = Gravity.CENTER
                    setPadding(0, dp(5), 0, 0)
                }
            )

            row.addView(
                card,
                LinearLayout.LayoutParams(0, dp(105), 1f).apply {
                    if (index == 0) marginEnd = dp(6)
                    else marginStart = dp(6)
                    bottomMargin = dp(10)
                }
            )
        }

        parent.addView(row)
    }

    private fun chatPage(): View {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        val heading = label("ТВОЙ ДИАЛОГ", 12f, cyan, true)
        heading.setPadding(dp(3), dp(4), 0, dp(10))
        page.addView(heading)

        val scroll = ScrollView(this).apply {
            isFillViewport = true
        }

        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(10))
        }

        if (messages.isEmpty()) {
            val welcome = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(17), dp(20), dp(17), dp(20))
                background = rounded(
                    intArrayOf(
                        Color.rgb(39, 28, 73),
                        Color.rgb(20, 30, 59)
                    ), 20
                )
            }

            welcome.addView(label("✦  AI CHAT PRO", 12f, cyan, true))
            welcome.addView(
                label("С чего начнём?", 23f, white, true).apply {
                    setPadding(0, dp(9), 0, dp(5))
                }
            )
            welcome.addView(
                label(
                    "Напиши сообщение внизу экрана. После подключения GGUF-движка здесь появятся настоящие ответы модели.",
                    14f,
                    muted
                )
            )
            list.addView(welcome)
        }

        messages.forEach { message ->
            val bubble = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), dp(12), dp(14), dp(12))
                background = rounded(
                    if (message.user) {
                        intArrayOf(
                            Color.rgb(77, 42, 135),
                            Color.rgb(42, 53, 119)
                        )
                    } else {
                        intArrayOf(
                            Color.rgb(26, 39, 62),
                            Color.rgb(39, 28, 60)
                        )
                    }, 18
                )
            }

            bubble.addView(
                label(
                    message.author,
                    11f,
                    if (message.user) cyan else purple,
                    true
                )
            )

            bubble.addView(
                label(message.text, 14f, white).apply {
                    setPadding(0, dp(6), 0, 0)
                }
            )

            val params = LinearLayout.LayoutParams(
                if (message.user) (resources.displayMetrics.widthPixels * 0.78).toInt()
                else -1,
                -2
            )

            params.gravity = if (message.user) Gravity.END else Gravity.START
            params.setMargins(0, dp(5), 0, dp(7))
            list.addView(bubble, params)
        }

        scroll.addView(list)

        page.addView(
            scroll,
            LinearLayout.LayoutParams(-1, 0, 1f)
        )

        val composer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(9), 0, 0)
        }

        val field = EditText(this).apply {
            hint = "Напиши сообщение..."
            setHintTextColor(muted)
            setTextColor(white)
            textSize = 14f
            maxLines = 3
            inputType = InputType.TYPE_CLASS_TEXT or
                InputType.TYPE_TEXT_FLAG_MULTI_LINE
            setPadding(dp(14), dp(10), dp(10), dp(10))
            background = rounded(intArrayOf(panel), 17)
        }

        composer.addView(
            field,
            LinearLayout.LayoutParams(0, dp(52), 1f)
        )

        val send = TextView(this).apply {
            text = "➤"
            textSize = 22f
            gravity = Gravity.CENTER
            setTextColor(white)
            background = rounded(
                intArrayOf(cyan, purple, pink), 17
            )
            setOnClickListener {
                val text = field.text.toString().trim()
                if (text.isNotEmpty()) {
                    messages.add(Message("Вы", text, true))
                    messages.add(
                        Message(
                            "AI CHAT PRO",
                            "Сообщение сохранено. Для генерации настоящего ответа необходимо подключить GGUF-движок.",
                            false
                        )
                    )
                    saveMessages()
                    render()
                }
            }
        }

        composer.addView(
            send,
            LinearLayout.LayoutParams(dp(52), dp(52)).apply {
                marginStart = dp(8)
            }
        )

        page.addView(composer)

        return page
    }

    private fun modelsPage(): View {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        page.addView(label("МОИ МОДЕЛИ", 20f, white, true))
        page.addView(
            label(
                "Выбирай GGUF-файл из памяти телефона.",
                13f,
                muted
            ).apply {
                setPadding(0, dp(6), 0, dp(18))
            }
        )

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(17), dp(18), dp(17), dp(18))
            background = rounded(
                intArrayOf(
                    Color.rgb(44, 27, 77),
                    Color.rgb(22, 30, 59)
                ), 20
            )
        }

        card.addView(label("◈  ЛОКАЛЬНАЯ МОДЕЛЬ", 12f, cyan, true))
        card.addView(
            label(modelName, 16f, white, true).apply {
                setPadding(0, dp(12), 0, dp(7))
            }
        )

        card.addView(
            label(
                if (modelUri != null)
                    "Файл выбран. Движок ещё не подключён."
                else
                    "Файл GGUF пока не выбран.",
                12f,
                muted
            )
        )

        page.addView(card)

        val choose = makeButton(
            "ВЫБРАТЬ GGUF-ФАЙЛ",
            intArrayOf(cyan, purple)
        ) {
            chooseModel()
        }

        page.addView(
            choose,
            LinearLayout.LayoutParams(-1, dp(53)).apply {
                topMargin = dp(15)
            }
        )

        val note = label(
            "Поддерживается выбор файла .gguf. Само подключение модели и генерация ответов будут добавлены после интеграции llama.cpp.",
            13f,
            muted
        )

        note.setPadding(dp(5), dp(16), dp(5), 0)
        page.addView(note)

        if (modelUri != null) {
            page.addView(
                makeButton("ОТКЛЮЧИТЬ ВЫБРАННЫЙ ФАЙЛ", intArrayOf(purple, pink)) {
                    modelUri = null
                    modelName = "Модель не выбрана"
                    prefs.edit()
                        .remove("model_uri")
                        .putString("model_name", modelName)
                        .apply()
                    render()
                }.apply {
                    setPadding(0, dp(14), 0, dp(14))
                },
                LinearLayout.LayoutParams(-1, dp(52)).apply {
                    topMargin = dp(12)
                }
            )
        }

        return page
    }

    private fun chooseModel() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }

        startActivityForResult(intent, 100)
    }

    @Deprecated("Using document picker for broad Android compatibility")
    override fun onActivityResult(
        requestCode: Int,
        resultCode: Int,
        data: Intent?
    ) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == 100 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return

            val name = getFileName(uri)

            if (!name.lowercase().endsWith(".gguf")) {
                Toast.makeText(
                    this,
                    "Выбери файл с расширением .gguf",
                    Toast.LENGTH_LONG
                ).show()
                return
            }

            try {
                contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {
            }

            modelUri = uri
            modelName = name

            prefs.edit()
                .putString("model_uri", uri.toString())
                .putString("model_name", name)
                .apply()

            Toast.makeText(
                this,
                "GGUF-файл выбран",
                Toast.LENGTH_SHORT
            ).show()

            screen = "models"
            render()
        }
    }

    private fun getFileName(uri: Uri): String {
        var name = "model.gguf"
        var cursor: Cursor? = null

        try {
            cursor = contentResolver.query(uri, null, null, null, null)
            if (cursor != null && cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (index >= 0) name = cursor.getString(index)
            }
        } catch (_: Exception) {
        } finally {
            cursor?.close()
        }

        return name
    }

    private fun historyPage(): View {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        page.addView(label("ИСТОРИЯ ДИАЛОГОВ", 19f, white, true))

        page.addView(
            label(
                "Последние сохранённые сообщения",
                13f,
                muted
            ).apply {
                setPadding(0, dp(6), 0, dp(16))
            }
        )

        if (messages.isEmpty()) {
            page.addView(
                label(
                    "Пока нет сохранённых сообщений. Начни новый чат!",
                    15f,
                    muted
                ).apply {
                    setPadding(dp(12), dp(15), dp(12), dp(15))
                }
            )
        } else {
            val scroll = ScrollView(this)
            val list = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
            }

            messages.forEach {
                val item = TextView(this).apply {
                    text = "${it.author}: ${it.text}"
                    textSize = 13f
                    maxLines = 3
                    setTextColor(white)
                    setPadding(dp(14), dp(13), dp(14), dp(13))
                    background = rounded(intArrayOf(panel), 15)
                }

                list.addView(
                    item,
                    LinearLayout.LayoutParams(-1, -2).apply {
                        bottomMargin = dp(7)
                    }
                )
            }

            scroll.addView(list)
            page.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        }

        page.addView(
            makeButton("ОТКРЫТЬ ЧАТ", intArrayOf(cyan, purple)) {
                screen = "chat"
                render()
            }
        )

        page.addView(
            makeButton("ОЧИСТИТЬ ИСТОРИЮ", intArrayOf(purple, pink)) {
                messages.clear()
                saveMessages()
                render()
            }.apply {
                setPadding(0, dp(12), 0, dp(12))
            }
        )

        return page
    }

    private fun settingsPage(): View {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        page.addView(label("НАСТРОЙКИ", 21f, white, true))

        page.addView(
            label(
                "Настрой внешний вид AI CHAT PRO.",
                13f,
                muted
            ).apply {
                setPadding(0, dp(6), 0, dp(18))
            }
        )

        val themeCard = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(15), dp(15), dp(15), dp(15))
            background = rounded(intArrayOf(panel), 17)
        }

        val themeText = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        themeText.addView(label("NEON FUTURE", 15f, white, true))
        themeText.addView(
            label("Яркое неоновое оформление", 12f, muted)
        )

        themeCard.addView(themeText, LinearLayout.LayoutParams(0, -2, 1f))

        val toggle = Switch(this).apply {
            isChecked = neon
            buttonTintList = android.content.res.ColorStateList.valueOf(cyan)
            setOnCheckedChangeListener { _, checked ->
                neon = checked
                prefs.edit().putBoolean("neon", neon).apply()
                render()
            }
        }

        themeCard.addView(toggle)
        page.addView(themeCard)

        page.addView(
            label(
                "Версия приложения: NEON FUTURE\n\nЛокальная генерация: пока не подключена.\n\nДвижок GGUF будет интегрирован отдельно.",
                13f,
                muted
            ).apply {
                setPadding(dp(5), dp(20), dp(5), 0)
            }
        )

        return page
    }

    private fun addNav(
        nav: LinearLayout,
        icon: String,
        title: String,
        destination: String
    ) {
        val active = screen == destination

        val item = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setOnClickListener {
                screen = destination
                render()
            }
        }

        item.addView(
            label(
                icon,
                21f,
                if (active) cyan else muted,
                true
            ).apply {
                gravity = Gravity.CENTER
            }
        )

        item.addView(
            label(
                title,
                9f,
                if (active) white else muted,
                active
            ).apply {
                gravity = Gravity.CENTER
            }
        )

        nav.addView(
            item,
            LinearLayout.LayoutParams(0, -1, 1f)
        )
    }

    private fun makeButton(
        text: String,
        colors: IntArray,
        click: () -> Unit
    ): TextView {
        return TextView(this).apply {
            this.text = text
            textSize = 12f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(white)
            background = rounded(colors, 17)
            setOnClickListener { click() }
        }
    }

    private fun label(
        text: String,
        size: Float,
        color: Int,
        bold: Boolean = false
    ): TextView {
        return TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }
    }

    private fun rounded(
        colors: IntArray,
        radius: Int
    ): GradientDrawable {
        return GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            colors
        ).apply {
            cornerRadius = dp(radius).toFloat()
        }
    }

    private fun saveMessages() {
        val array = JSONArray()

        messages.forEach {
            array.put(
                JSONObject().apply {
                    put("author", it.author)
                    put("text", it.text)
                    put("user", it.user)
                }
            )
        }

        prefs.edit().putString("messages", array.toString()).apply()
    }

    private fun loadMessages() {
        try {
            val array = JSONArray(
                prefs.getString("messages", "[]")
            )

            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                messages.add(
                    Message(
                        item.getString("author"),
                        item.getString("text"),
                        item.getBoolean("user")
                    )
                )
            }
        } catch (_: Exception) {
            messages.clear()
        }
    }

    private fun dp(value: Int): Int {
        return (value * resources.displayMetrics.density).toInt()
    }
}

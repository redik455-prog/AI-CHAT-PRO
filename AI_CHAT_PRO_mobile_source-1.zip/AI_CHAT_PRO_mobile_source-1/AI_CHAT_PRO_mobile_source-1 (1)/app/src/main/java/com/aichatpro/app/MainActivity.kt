
package com.aichatpro.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val bg = Color.rgb(5, 10, 25)
    private val blue = Color.rgb(0, 190, 255)
    private val purple = Color.rgb(145, 75, 255)
    private val white = Color.WHITE

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private fun text(
        value: String,
        size: Float,
        color: Int,
        bold: Boolean = false
    ): TextView {
        return TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            gravity = Gravity.CENTER
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
    }

    private fun background(
        color: Int,
        stroke: Int = blue
    ): GradientDrawable {
        return GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(18).toFloat()
            setStroke(dp(1), stroke)
        }
    }

    private fun makeButton(
        label: String,
        color: Int,
        action: String
    ): TextView {
        return text(label, 16f, white, true).apply {
            background = this@MainActivity.background(
                Color.rgb(12, 23, 48),
                color
            )
            setPadding(dp(12), dp(18), dp(12), dp(18))
            setOnClickListener {
                Toast.makeText(
                    this@MainActivity,
                    action,
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = bg
        window.navigationBarColor = bg

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }

        val scroll = ScrollView(this)

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(20))
        }

        content.addView(
            text("☰       AI CHAT PRO       ⚙", 21f, blue, true)
        )

        content.addView(
            text("Ваш интеллектуальный помощник", 15f, white)
        )

        // Изображение мозга ИИ
        val brain = ImageView(this).apply {
            setImageResource(R.drawable.brain)
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
            setPadding(dp(10), dp(15), dp(10), dp(15))
            contentDescription = "Изображение искусственного интеллекта"
        }

        content.addView(
            brain,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(230)
            )
        )

        content.addView(
            text("ИСКУССТВЕННЫЙ ИНТЕЛЛЕКТ", 13f, blue, true)
        )

        content.addView(
            text(
                "Задавайте вопросы — получайте умные ответы",
                16f,
                white
            )
        )

        val start = text(
            "✦   НАЧАТЬ ЧАТ   ➜",
            20f,
            white,
            true
        ).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(blue, purple)
            ).apply {
                cornerRadius = dp(22).toFloat()
            }

            setPadding(dp(15), dp(20), dp(15), dp(20))

            setOnClickListener {
                Toast.makeText(
                    this@MainActivity,
                    "Экран чата добавим следующим этапом",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        content.addView(start)

        content.addView(
            makeButton(
                "📦   МОИ МОДЕЛИ",
                purple,
                "Раздел моделей добавим следующим этапом"
            ).apply {
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply {
                    topMargin = dp(14)
                }
            }
        )

        val row1 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }

        row1.addView(
            makeButton(
                "🕘\nИстория диалогов",
                blue,
                "Историю добавим следующим этапом"
            ),
            LinearLayout.LayoutParams(0, -2, 1f)
        )

        row1.addView(
            makeButton(
                "⚙\nВыбрать модель",
                purple,
                "Выбор модели добавим следующим этапом"
            ),
            LinearLayout.LayoutParams(0, -2, 1f)
        )

        content.addView(row1)

        val row2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }

        row2.addView(
            makeButton(
                "🎙\nГолосовой ввод",
                blue,
                "Голосовой ввод добавим позже"
            ),
            LinearLayout.LayoutParams(0, -2, 1f)
        )

        row2.addView(
            makeButton(
                "☷\nПараметры ИИ",
                purple,
                "Настройки добавим следующим этапом"
            ),
            LinearLayout.LayoutParams(0, -2, 1f)
        )

        content.addView(row2)

        content.addView(
            text(
                "●  ПРИЛОЖЕНИЕ ГОТОВО К РАБОТЕ",
                14f,
                Color.rgb(0, 220, 140),
                true
            )
        )

        content.addView(
            text("AI CHAT PRO  •  NEON FUTURE", 12f, blue)
        )

        scroll.addView(content)

        root.addView(
            scroll,
            LinearLayout.LayoutParams(-1, 0, 1f)
        )

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(8))
            background = this@MainActivity.background(
                Color.rgb(9, 16, 35),
                purple
            )
        }

        val tabs = listOf(
            "⌂\nГлавная",
            "▢\nЧат",
            "□\nФайлы",
            "▥\nСтатистика",
            "⚙\nНастройки"
        )

        for (tab in tabs) {
            val item = text(tab, 12f, blue, true)

            bottom.addView(
                item,
                LinearLayout.LayoutParams(0, -2, 1f)
            )
        }

        root.addView(bottom)

        setContentView(root)
    }
}

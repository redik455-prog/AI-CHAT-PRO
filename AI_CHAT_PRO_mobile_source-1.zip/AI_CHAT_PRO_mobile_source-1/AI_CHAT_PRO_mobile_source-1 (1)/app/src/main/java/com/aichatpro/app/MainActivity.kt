package com.aichatpro.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = Color.rgb(8, 8, 18)
        window.navigationBarColor = Color.rgb(8, 8, 18)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
            setBackgroundColor(Color.rgb(8, 8, 18))
        }

        val title = TextView(this).apply {
            text = "AI CHAT PRO"
            textSize = 34f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(0, 230, 255))
            gravity = Gravity.CENTER
        }

        val subtitle = TextView(this).apply {
            text = "NEON FUTURE"
            textSize = 17f
            setTextColor(Color.rgb(190, 80, 255))
            gravity = Gravity.CENTER
        }

        val status = TextView(this).apply {
            text = "Система запущена"
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }

        root.addView(title)
        root.addView(subtitle)

        val space = TextView(this).apply {
            text = ""
            height = 45
        }
        root.addView(space)
        root.addView(status)

        setContentView(root)
    }
}

package com.aichatpro.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.*
import android.text.InputType

class MainActivity : Activity() {

    private lateinit var messages: LinearLayout
    private lateinit var input: EditText
    private lateinit var scroll: ScrollView

    private val bg = Color.rgb(8, 9, 20)
    private val panel = Color.rgb(23, 24, 43)
    private val white = Color.WHITE
    private val muted = Color.rgb(164, 166, 194)

    private val cyan = Color.rgb(0, 220, 255)
    private val purple = Color.rgb(160, 80, 255)
    private val pink = Color.rgb(255, 65, 180)
    private val blue = Color.rgb(65, 110, 255)
    private val green = Color.rgb(40, 230, 170)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = bg
        window.navigationBarColor = bg

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }

        // HEADER
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, dp(18))
        }

        val logo = TextView(this).apply {
            text = "✦"
            textSize = 29f
            gravity = Gravity.CENTER
            setTextColor(cyan)
            background = rounded(
                intArrayOf(
                    Color.rgb(28, 42, 82),
                    Color.rgb(62, 30, 92)
                ), 18
            )
        }

        header.addView(logo, LinearLayout.LayoutParams(dp(50), dp(50)))

        val heading = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
        }

        val title = TextView(this).apply {
            text = "AI CHAT PRO"
            textSize = 22f
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
        }

        val subtitle = TextView(this).apply {
            text = "YOUR PERSONAL AI ASSISTANT"
            textSize = 9f
            letterSpacing = 0.12f
            setTextColor(cyan)
        }

        heading.addView(title)
        heading.addView(subtitle)

        header.addView(
            heading,
            LinearLayout.LayoutParams(0, -2, 1f)
        )

        val menu = TextView(this).apply {
            text = "⋮"
            textSize = 28f
            gravity = Gravity.CENTER
            setTextColor(white)
            setOnClickListener {
                Toast.makeText(
                    this@MainActivity,
                    "Настройки скоро появятся",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        header.addView(menu, LinearLayout.LayoutParams(dp(40), dp(45)))
        root.addView(header)

        // MAIN SCROLL AREA
        scroll = ScrollView(this).apply {
            isFillViewport = false
            clipToPadding = false
        }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        // WELCOME CARD
        val welcome = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(20))
            background = rounded(
                intArrayOf(
                    Color.rgb(39, 27, 80),
                    Color.rgb(20, 28, 65),
                    Color.rgb(15, 42, 57)
                ), 24
            )
        }

        val glow = TextView(this).apply {
            text = "✧  NEXT GENERATION AI"
            textSize = 11f
            setTextColor(cyan)
        }

        val hello = TextView(this).apply {
            text = "Привет! 👋"
            textSize = 29f
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(12), 0, dp(4))
        }

        val welcomeText = TextView(this).apply {
            text = "Твой умный помощник всегда рядом. Готов отвечать, создавать и помогать."
            textSize = 14f
            setTextColor(Color.rgb(210, 213, 240))
            setLineSpacing(dp(3).toFloat(), 1f)
        }

        welcome.addView(glow)
        welcome.addView(hello)
        welcome.addView(welcomeText)

        val localStatus = TextView(this).apply {
            text = "●  ЛОКАЛЬНАЯ МОДЕЛЬ НЕ ПОДКЛЮЧЕНА"
            textSize = 10f
            setTextColor(Color.rgb(255, 190, 110))
            setPadding(0, dp(16), 0, 0)
        }

        welcome.addView(localStatus)

        content.addView(
            welcome,
            LinearLayout.LayoutParams(-1, -2).apply {
                bottomMargin = dp(20)
            }
        )

        // QUICK ACTIONS TITLE
        val sectionTitle = TextView(this).apply {
            text = "БЫСТРЫЙ ДОСТУП"
            textSize = 12f
            letterSpacing = 0.12f
            setTextColor(muted)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(2), 0, 0, dp(10))
        }

        content.addView(sectionTitle)

        // QUICK ACTIONS
        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }

        actions.addView(
            actionCard("✦", "Новый чат", cyan) {
                input.requestFocus()
            },
            LinearLayout.LayoutParams(0, dp(100), 1f).apply {
                marginEnd = dp(6)
            }
        )

        actions.addView(
            actionCard("◈", "Мои модели", purple) {
                showModelInfo()
            },
            LinearLayout.LayoutParams(0, dp(100), 1f).apply {
                marginStart = dp(6)
            }
        )

        content.addView(actions)

        val secondActions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(10), 0, dp(20))
        }

        secondActions.addView(
            actionCard("◷", "История", green) {
                Toast.makeText(
                    this@MainActivity,
                    "История появится в следующем обновлении",
                    Toast.LENGTH_SHORT
                ).show()
            },
            LinearLayout.LayoutParams(0, dp(90), 1f).apply {
                marginEnd = dp(6)
            }
        )

        secondActions.addView(
            actionCard("⚙", "Настройки", pink) {
                Toast.makeText(
                    this@MainActivity,
                    "Настройки скоро появятся",
                    Toast.LENGTH_SHORT
                ).show()
            },
            LinearLayout.LayoutParams(0, dp(90), 1f).apply {
                marginStart = dp(6)
            }
        )

        content.addView(secondActions)

        // CHAT
        val chatTitle = TextView(this).apply {
            text = "ТВОЙ ДИАЛОГ"
            textSize = 12f
            letterSpacing = 0.12f
            setTextColor(muted)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(2), 0, 0, dp(10))
        }

        content.addView(chatTitle)

        messages = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        content.addView(messages)

        scroll.addView(content)

        root.addView(
            scroll,
            LinearLayout.LayoutParams(-1, 0, 1f)
        )

        // MODEL BUTTON
        val modelButton = TextView(this).apply {
            text = "✦   ПОДКЛЮЧИТЬ GGUF-МОДЕЛЬ"
            textSize = 13f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(white)
            background = rounded(
                intArrayOf(purple, pink),
                18
            )
            setPadding(0, dp(16), 0, dp(16))
            setOnClickListener {
                showModelInfo()
            }
        }

        root.addView(
            modelButton,
            LinearLayout.LayoutParams(-1, dp(52)).apply {
                topMargin = dp(10)
            }
        )

        // MESSAGE INPUT
        val composer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, 0)
        }

        input = EditText(this).apply {
            hint = "Напиши сообщение..."
            setHintTextColor(muted)
            setTextColor(white)
            textSize = 14f
            singleLine = true
            imeOptions = EditorInfo.IME_ACTION_SEND
            inputType = InputType.TYPE_CLASS_TEXT
            setPadding(dp(16), 0, dp(12), 0)
            background = rounded(
                intArrayOf(
                    Color.rgb(29, 30, 52),
                    Color.rgb(35, 29, 55)
                ), 18
            )

            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_SEND) {
                    sendMessage()
                    true
                } else {
                    false
                }
            }
        }

        composer.addView(
            input,
            LinearLayout.LayoutParams(0, dp(54), 1f)
        )

        val send = TextView(this).apply {
            text = "➤"
            textSize = 23f
            gravity = Gravity.CENTER
            setTextColor(white)
            background = rounded(
                intArrayOf(cyan, blue, purple),
                18
            )
            setOnClickListener {
                sendMessage()
            }
        }

        composer.addView(
            send,
            LinearLayout.LayoutParams(dp(54), dp(54)).apply {
                marginStart = dp(8)
            }
        )

        root.addView(composer)

        setContentView(root)
    }

    private fun actionCard(
        symbol: String,
        label: String,
        color: Int,
        click: () -> Unit
    ): LinearLayout {

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = rounded(
                intArrayOf(
                    Color.rgb(28, 29, 51),
                    Color.rgb(20, 22, 39)
                ), 18
            )
            setOnClickListener { click() }
        }

        val icon = TextView(this).apply {
            text = symbol
            textSize = 27f
            gravity = Gravity.CENTER
            setTextColor(color)
        }

        val text = TextView(this).apply {
            text = label
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(5), 0, 0)
        }

        card.addView(icon)
        card.addView(text)

        return card
    }

    private fun sendMessage() {
        val message = input.text.toString().trim()

        if (message.isEmpty()) return

        addMessage("Вы", message, true)

        addMessage(
            "AI CHAT PRO",
            "Интерфейс обновлён! Для генерации настоящих ответов необходимо подключить локальный GGUF-движок.",
            false
        )

        input.text.clear()

        scroll.post {
            scroll.fullScroll(View.FOCUS_DOWN)
        }
    }

    private fun addMessage(
        who: String,
        body: String,
        user: Boolean
    ) {
        val card = TextView(this).apply {
            text = "$who\n\n$body"
            textSize = 14f
            setTextColor(white)
            setPadding(dp(15), dp(13), dp(15), dp(13))

            background = rounded(
                if (user) {
                    intArrayOf(
                        Color.rgb(72, 48, 132),
                        Color.rgb(45, 49, 111)
                    )
                } else {
                    intArrayOf(
                        Color.rgb(27, 34, 59),
                        Color.rgb(35, 26, 57)
                    )
                },
                18
            )
        }

        val params = LinearLayout.LayoutParams(
            if (user) (resources.displayMetrics.widthPixels * 0.78).toInt()
            else -1,
            -2
        )

        params.gravity = if (user) Gravity.END else Gravity.START
        params.setMargins(0, dp(5), 0, dp(7))

        messages.addView(card, params)
    }

    private fun showModelInfo() {
        Toast.makeText(
            this,
            "Подключение GGUF-движка будет следующим этапом.",
            Toast.LENGTH_LONG
        ).show()
    }

    private fun rounded(
        colors: IntArray,
        radius: Int
    ): GradientDrawable {
        return GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            colors
        ).apply {
            cornerRadius = dp(radius).toFloat()
        }
    }

    private fun dp(value: Int): Int {
        return (value * resources.displayMetrics.density).toInt()
    }
}

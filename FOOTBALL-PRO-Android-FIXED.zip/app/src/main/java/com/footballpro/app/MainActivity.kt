package com.footballpro.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Night = Color(0xFF07130F)
private val Panel = Color(0xFF10231B)
private val Lime = Color(0xFFB7F34A)
private val Gold = Color(0xFFFFD166)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FootballProApp() }
    }
}

@Composable
fun FootballProApp() {
    var tab by remember { mutableStateOf("Матчи") }
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Lime, secondary = Gold, background = Night, surface = Panel
    )) {
        Scaffold(containerColor = Night, bottomBar = {
            NavigationBar(containerColor = Panel, contentColor = Lime) {
                listOf("Матчи", "Прогнозы", "Статистика").forEach { item ->
                    NavigationBarItem(
                        selected = tab == item,
                        onClick = { tab = item },
                        icon = { Icon(Icons.Default.SportsSoccer, contentDescription = null) },
                        label = { Text(item) }
                    )
                }
            }
        }) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding)
                    .background(Brush.verticalGradient(listOf(Color(0xFF10291D), Night))),
                contentPadding = PaddingValues(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(shape = RoundedCornerShape(16.dp), color = Lime, modifier = Modifier.size(54.dp)) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.EmojiEvents, contentDescription = "FOOTBALL PRO",
                                    tint = Night, modifier = Modifier.size(34.dp))
                            }
                        }
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text("FOOTBALL PRO", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black)
                            Text("УМНАЯ ФУТБОЛЬНАЯ АНАЛИТИКА", color = Lime, fontSize = 10.sp, letterSpacing = 1.2.sp)
                        }
                    }
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                        Column(Modifier.padding(18.dp)) {
                            Text("ПАНЕЛЬ ПРОГНОЗОВ", color = Lime, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(8.dp))
                            Text("Анализируй матчи. Проверяй вероятности.", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(6.dp))
                            Text("Автономная версия • без API", color = Color.LightGray, fontSize = 13.sp)
                        }
                    }
                }
                item { Text(if (tab == "Матчи") "ДЕМО-МАТЧИ" else tab.uppercase(), color = Gold, fontWeight = FontWeight.Bold) }
                item { MatchCard("Манчестер Сити", "Арсенал", "Премьер-лига", "46%", "28%", "26%") }
                item { MatchCard("Реал Мадрид", "Барселона", "Ла Лига", "42%", "25%", "33%") }
                item {
                    Text("Примечание: демонстрационные матчи и вероятности не являются актуальными прогнозами. Добавьте собственную статистику для расчётов.",
                        color = Color.LightGray, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun MatchCard(home: String, away: String, league: String, p1: String, draw: String, p2: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Text(league.uppercase(), color = Lime, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(home, color = Color.White, fontWeight = FontWeight.Bold)
                    Text("Хозяева", color = Color.LightGray, fontSize = 11.sp)
                }
                Text("VS", color = Gold, fontWeight = FontWeight.Black)
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                    Text(away, color = Color.White, fontWeight = FontWeight.Bold)
                    Text("Гости", color = Color.LightGray, fontSize = 11.sp)
                }
            }
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Probability("П1", p1, Modifier.weight(1f))
                Probability("X", draw, Modifier.weight(1f))
                Probability("П2", p2, Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun Probability(label: String, value: String, modifier: Modifier) {
    Surface(modifier, color = Color(0xFF1B3829), shape = RoundedCornerShape(12.dp)) {
        Column(Modifier.padding(vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(label, color = Color.LightGray, fontSize = 11.sp)
            Text(value, color = Lime, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        }
    }
}

# FOOTBALL PRO

Автономный демонстрационный Android-проект на Kotlin и Jetpack Compose.

## Сборка
- JDK 17
- Android Gradle Plugin 8.7.3
- Gradle 8.9
- Android SDK 35

В GitHub Actions workflow используется `gradle --no-daemon assembleDebug`.

## Важно
Матчи и проценты в стартовом интерфейсе демонстрационные. Приложение не получает актуальные матчи и не гарантирует точность прогнозов. Для реальных расчётов нужно добавить проверенную статистику команд и модель прогнозирования.

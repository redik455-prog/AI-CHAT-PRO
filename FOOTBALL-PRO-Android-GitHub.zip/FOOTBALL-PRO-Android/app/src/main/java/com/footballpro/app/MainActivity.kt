package com.footballpro.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF07131C)
private val Panel = Color(0xFF10232D)
private val Lime = Color(0xFFA8FF00)
private val Muted = Color(0xFF9EB0B9)

data class Match(val home: String, val away: String, val league: String, val hs: Double, val hc: Double, val asg: Double, val ac: Double)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FootballProApp() }
    }
}

@Composable
fun FootballProApp() {
    var tab by remember { mutableStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    var matches by remember {
        mutableStateOf(listOf(
            Match("Реал Мадрид", "Барселона", "Ла Лига", 2.1, 0.9, 2.0, 1.1),
            Match("Арсенал", "Челси", "Премьер-лига", 1.9, 0.8, 1.6, 1.3),
            Match("Интер", "Милан", "Серия А", 1.8, 0.7, 1.5, 1.0)
        ))
    }
    MaterialTheme(colorScheme = darkColorScheme(primary = Lime, background = Bg, surface = Panel)) {
        Scaffold(containerColor = Bg, floatingActionButton = {
            FloatingActionButton(onClick = { showAdd = true }, containerColor = Lime, contentColor = Bg) { Icon(Icons.Default.Add, null) }
        }, bottomBar = {
            NavigationBar(containerColor = Color(0xFF0A1B24), contentColor = Lime) {
                listOf("Главная", "Матчи", "Аналитика", "Избранное").forEachIndexed { i, label ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i },
                        icon = { Icon(listOf(Icons.Default.Home, Icons.Default.EmojiEvents, Icons.Default.Analytics, Icons.Default.Favorite)[i], null) },
                        label = { Text(label, fontSize = 10.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Lime, selectedTextColor = Lime, indicatorColor = Color(0xFF203B25), unselectedTextColor = Muted))
                }
            }
        }) { pad ->
            Column(Modifier.fillMaxSize().padding(pad).padding(horizontal = 16.dp)) {
                Header()
                when (tab) {
                    0 -> HomeScreen(matches)
                    1 -> MatchesScreen(matches)
                    2 -> AnalyticsScreen(matches)
                    else -> EmptyFavorites()
                }
            }
        }
    }
    if (showAdd) AddMatchDialog(onDismiss = { showAdd = false }, onAdd = { matches = matches + it; showAdd = false })
}

@Composable
fun Header() {
    Row(Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 16.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(48.dp).background(Brush.linearGradient(listOf(Color(0xFF214B32), Color(0xFF0B1B22))), RoundedCornerShape(15.dp)), contentAlignment = Alignment.Center) {
            Text("⚽", fontSize = 27.sp)
            Text("♛", color = Color(0xFFFFD15A), fontSize = 16.sp, modifier = Modifier.offset(y = (-17).dp))
        }
        Spacer(Modifier.width(10.dp))
        Column {
            Text("FOOTBALL ", color = Color.White, fontWeight = FontWeight.Black, fontSize = 22.sp)
            Text("PRO • OFFLINE ANALYTICS", color = Lime, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
        }
        Spacer(Modifier.weight(1f))
        Text("● OFFLINE", color = Lime, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun HomeScreen(matches: List<Match>) {
    Column {
        Box(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Color(0xFF163F31), Color(0xFF10202C))), RoundedCornerShape(22.dp)).padding(18.dp)) {
            Column {
                Text("УМНЫЕ ПРОГНОЗЫ", color = Lime, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Text("Футбол в цифрах.", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black)
                Text("Анализируй. Сравнивай. Принимай решения.", color = Muted, fontSize = 12.sp)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatChip("100%", "локальные расчёты")
                    StatChip("0 API", "без ключей")
                }
            }
        }
        Spacer(Modifier.height(18.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Матчи и прогнозы", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Text("${matches.size} матчей", color = Lime, fontSize = 12.sp)
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 90.dp)) {
            items(matches) { MatchCard(it) }
            item { Text("Прогнозы ориентировочные. Проверяй исходные данные и учитывай неопределённость.", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(vertical = 12.dp)) }
        }
    }
}

@Composable
fun StatChip(value: String, label: String) {
    Column(Modifier.background(Color(0xFF0B1C24), RoundedCornerShape(12.dp)).padding(horizontal = 12.dp, vertical = 8.dp)) {
        Text(value, color = Lime, fontWeight = FontWeight.Black, fontSize = 17.sp)
        Text(label, color = Muted, fontSize = 10.sp)
    }
}

@Composable
fun MatchCard(m: Match) {
    val f = remember(m) { PredictionEngine.predict(TeamStats(m.home, m.hs, m.hc, 1.08), TeamStats(m.away, m.asg, m.ac)) }
    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(m.league.uppercase(), color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Spacer(Modifier.weight(1f))
            Text("АНАЛИЗ", color = Lime, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(m.home, color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text("VS", color = Lime, fontWeight = FontWeight.Black, fontSize = 13.sp)
            Text(m.away, color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.End)
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth().background(Color(0xFF0A1B22), RoundedCornerShape(12.dp)).padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Probability("П1", f.homeWin)
            Probability("Х", f.draw)
            Probability("П2", f.awayWin)
            Probability("ТБ 2.5", f.over25)
            Probability("ОЗ", f.bothScore)
        }
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Модель: ${f.pick}", color = Lime, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Spacer(Modifier.weight(1f))
            Text("Уверенность ${f.confidence}%", color = Muted, fontSize = 11.sp)
        }
        Text("Ожидаемые голы: %.1f : %.1f".format(f.expectedHomeGoals, f.expectedAwayGoals), color = Muted, fontSize = 11.sp)
    }
}

@Composable
fun Probability(label: String, value: Int) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text("$value%", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        Text(label, color = Muted, fontSize = 9.sp)
    }
}

@Composable
fun MatchesScreen(matches: List<Match>) {
    Column {
        Text("Твои матчи", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("Добавляй пары команд и их средние показатели за матч.", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 90.dp)) { items(matches) { MatchCard(it) } }
    }
}

@Composable
fun AnalyticsScreen(matches: List<Match>) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Центр аналитики", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("Расчёты выполняются на устройстве по введённой статистике.", color = Muted, fontSize = 12.sp)
        StatRow("Матчей в базе", matches.size.toString())
        StatRow("Внешние API", "Не используются")
        StatRow("Сетевые разрешения", "Не требуются")
        StatRow("Модель", "Poisson / голевые средние")
        Text("Для честной оценки качества сохраняй прогнозы до начала матчей, а затем сверяй их с результатами. В этой стартовой версии автоматическая проверка результатов не включена.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
fun StatRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Muted, modifier = Modifier.weight(1f), fontSize = 13.sp)
        Text(value, color = Lime, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
}

@Composable
fun EmptyFavorites() {
    Column(Modifier.fillMaxWidth().padding(top = 60.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("☆", color = Lime, fontSize = 52.sp)
        Text("Избранное", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Text("Добавление избранных матчей появится в следующем обновлении.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
fun AddMatchDialog(onDismiss: () -> Unit, onAdd: (Match) -> Unit) {
    var home by remember { mutableStateOf("") }; var away by remember { mutableStateOf("") }; var league by remember { mutableStateOf("Своя лига") }
    var hs by remember { mutableStateOf("1.5") }; var hc by remember { mutableStateOf("1.0") }
    var asg by remember { mutableStateOf("1.4") }; var ac by remember { mutableStateOf("1.1") }
    AlertDialog(onDismissRequest = onDismiss, containerColor = Panel, title = { Text("Новый матч", color = Color.White, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                OutlinedTextField(home, { home = it }, label = { Text("Хозяева") }, singleLine = true)
                OutlinedTextField(away, { away = it }, label = { Text("Гости") }, singleLine = true)
                OutlinedTextField(league, { league = it }, label = { Text("Турнир") }, singleLine = true)
                Text("Средние голы за матч (забито / пропущено)", color = Lime, fontSize = 11.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(hs, { hs = it }, label = { Text("Х забито") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(hc, { hc = it }, label = { Text("Х пропущено") }, modifier = Modifier.weight(1f), singleLine = true)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(asg, { asg = it }, label = { Text("Г забито") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(ac, { ac = it }, label = { Text("Г пропущено") }, modifier = Modifier.weight(1f), singleLine = true)
                }
            }
        },
        confirmButton = { TextButton(onClick = {
            if (home.isNotBlank() && away.isNotBlank()) onAdd(Match(home.trim(), away.trim(), league.trim(), hs.toDoubleOrNull() ?: 1.5, hc.toDoubleOrNull() ?: 1.0, asg.toDoubleOrNull() ?: 1.4, ac.toDoubleOrNull() ?: 1.1))
        }) { Text("Рассчитать", color = Lime) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена", color = Muted) } })
}

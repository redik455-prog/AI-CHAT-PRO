package com.footballpro.app

import kotlin.math.exp
import kotlin.math.pow

data class TeamStats(
    val name: String,
    val scoredPerGame: Double,
    val concededPerGame: Double,
    val homeFactor: Double = 1.0
)

data class Forecast(
    val homeWin: Int,
    val draw: Int,
    val awayWin: Int,
    val over25: Int,
    val bothScore: Int,
    val expectedHomeGoals: Double,
    val expectedAwayGoals: Double,
    val pick: String,
    val confidence: Int
)

/**
 * Offline heuristic forecast. It is an estimate, not a guarantee or a trained professional model.
 * Probabilities are derived from attack/defence averages and a compact Poisson approximation.
 */
object PredictionEngine {
    private fun poisson(k: Int, lambda: Double): Double =
        exp(-lambda) * lambda.pow(k) / factorial(k)

    private fun factorial(n: Int): Double = when (n) {
        0, 1 -> 1.0
        else -> (2..n).fold(1.0) { a, b -> a * b }
    }

    fun predict(home: TeamStats, away: TeamStats): Forecast {
        val h = ((home.scoredPerGame + away.concededPerGame) / 2.0 * home.homeFactor).coerceIn(0.15, 4.0)
        val a = ((away.scoredPerGame + home.concededPerGame) / 2.0).coerceIn(0.15, 4.0)
        var pH = 0.0; var pD = 0.0; var pA = 0.0; var over = 0.0; var both = 0.0
        for (i in 0..6) for (j in 0..6) {
            val p = poisson(i, h) * poisson(j, a)
            if (i > j) pH += p else if (i == j) pD += p else pA += p
            if (i + j >= 3) over += p
            if (i > 0 && j > 0) both += p
        }
        val total = pH + pD + pA
        val probs = listOf(pH / total, pD / total, pA / total)
        val max = probs.maxOrNull() ?: 0.0
        val pick = when (probs.indexOf(max)) { 0 -> "П1"; 1 -> "Х"; else -> "П2" }
        return Forecast(
            (probs[0] * 100).toInt(), (probs[1] * 100).toInt(), (probs[2] * 100).toInt(),
            (over * 100).toInt(), (both * 100).toInt(), h, a, pick, (max * 100).toInt()
        )
    }
}
